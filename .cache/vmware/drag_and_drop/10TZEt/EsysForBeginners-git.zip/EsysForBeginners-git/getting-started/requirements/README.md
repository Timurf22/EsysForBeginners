# Requirements

There are a few basic requirements to run esys properly. This includes,

* A laptop with an ethernet port and Windows 10/11
* E-NET Cable&#x20;
* 5 Amp Battery Charger (it is possible without one, although if you own a BMW you can afford a harbor freight charger for peace of mind)
* Patience
