# Disable Antivirus

Any antivirus including windows defender believes that the patching tool for esys is a virus. Windows believes the behavior of the program is malicious, however we intend for it to patch the software. This is NOT a virus.

How to disable windows defender :&#x20;

First, open the windows security app through the windows button :&#x20;

<figure><img src="../../.gitbook/assets/{F20AA564-D952-489B-8FE7-93B135908742}.png" alt=""><figcaption></figcaption></figure>

Next, navigate to the virus and threat protection window, then click manage settings :

<figure><img src="../../.gitbook/assets/image.png" alt=""><figcaption></figcaption></figure>

From here, turn off real time Protection :

<figure><img src="../../.gitbook/assets/image (1).png" alt=""><figcaption></figcaption></figure>
