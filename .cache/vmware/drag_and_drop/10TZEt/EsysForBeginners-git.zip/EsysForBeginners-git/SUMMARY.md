# Table of contents

* [Getting started](README.md)
  * [Requirements](getting-started/requirements/README.md)
    * [Compatible ENET Cables](getting-started/requirements/compatible-enet-cables.md)
  * [Software Installation](getting-started/software-installation/README.md)
    * [Disable Antivirus](getting-started/software-installation/disable-antivirus.md)
    * [Download](getting-started/software-installation/download.md)
    * [Generating ESYS Token](getting-started/software-installation/generating-esys-token.md)
    * [PSDZData](getting-started/software-installation/psdzdata.md)
